package com.example.runnertracker.Model;

import static com.example.runnertracker.View.RunnerTracker.EXTRA_TERMINATE;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.runnertracker.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.ArrayList;
import java.util.Objects;

/*
    Service created to ensure location can be tracked in the background and main ui thread not interrupted

    Stores location data in ArrayList every second, subtracts distance from last -> first location
    to retrieve final distance travelled

    Sends data to RunnerTracker activity when service destroyed.

    Also for unknown reasons multiple calls to remove location updates must be made to stop the service.
 */
public class GPSService extends Service {

    public static final String ACTION_UPDATE_DATA = "GPS_DATA";
    public static final String EXTRA_DISTANCE = "com.example.runnertracker.EXTRA_DISTANCE";
    public static final String EXTRA_TIME = "com.example.runnertracker.EXTRA_TIME";
    private final String CHANNEL_ID = "100";
    private final int NOTIFICATION_ID = 001;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private ArrayList<Location> mLocationsVisited;
    private long startTime = 0;
    private long endTime = 0;
    private NotificationManager notificationManager;
    private PendingIntent pendingIntent;
    Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        initializeNotificationManager();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        final boolean getTerminate = intent.getBooleanExtra(EXTRA_TERMINATE, false);
            if(getTerminate || Objects.equals(intent.getAction(), "STOP")) {
                saveTravel();
                stopForeground(true);
                fusedLocationClient.removeLocationUpdates(locationCallback);
                mLocationsVisited.clear();
                stopSelf();
            }

        InitializeJourneyArray();
        getLocation();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        notificationBuilder();

    return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        notificationManager.cancel(NOTIFICATION_ID);
        fusedLocationClient.removeLocationUpdates(locationCallback);
        fusedLocationClient.removeLocationUpdates(pendingIntent);
        mLocationsVisited.clear();
        Log.d("comp3018", "GPS service destroyed through lifecycle");

    }

    // ArrayList initialized
    private void InitializeJourneyArray() {
        mLocationsVisited = new ArrayList<>();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void getLocation() {
        startTravelTime();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        LocationRequest locationRequest = new
                LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000).build();
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                for (Location location : locationResult.getLocations()) {
                    Log.d("comp3018", "location " + location.toString());
                    mLocationsVisited.add(location);
                }
            }
        };
        try {
            fusedLocationClient.requestLocationUpdates(locationRequest,
                    locationCallback,
                    Looper.getMainLooper());
        } catch(SecurityException e) {
            Toast.makeText(this,"This application is lacking location permissions, please enable", Toast.LENGTH_SHORT).show();
        }
    }

    // performing final calculations on distance + time.
    private void saveTravel() {
        double duration = totalDuration();
        double finalDistance = lengthOfTravel();

        sendMessageToActivity(duration, finalDistance);

        Log.d("comp3018", "km distance " + finalDistance);
        Log.d("comp3018", "final duration  " + duration);

        startTime = SystemClock.elapsedRealtime();
        endTime = 0;
    }

    private double lengthOfTravel() {
        if(mLocationsVisited.size() <= 1) {
            return 0;
        }
        int finalLocationIndex = mLocationsVisited.size() - 1;
        return mLocationsVisited.get(0).distanceTo(mLocationsVisited.get(finalLocationIndex))/1000;
        // m conversion to km
    }

    private void startTravelTime() {
        startTime = SystemClock.elapsedRealtime();
        endTime = 0;
    }

    private double totalDuration() {
        if (startTime == 0) {
            return 0.0;
        }

        long currentTime = SystemClock.elapsedRealtime();
        if (endTime != 0) {
            currentTime = endTime;
        }
        long elaspedTime = currentTime - startTime;
        return elaspedTime / 1000.0;

    }

    // send data to RunnerTracker
    private void sendMessageToActivity(double duration, double distance) {
        Intent intent = new Intent(ACTION_UPDATE_DATA);
        String durationString = Double.toString(duration);
        String distanceString = Double.toString(distance);
        intent.setAction(ACTION_UPDATE_DATA);


        intent.putExtra(EXTRA_DISTANCE, distanceString);
        intent.putExtra(EXTRA_TIME, durationString);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);

    }

    private void notificationBuilder() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this,
                CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_baseline_wb_sunny)
                .setContentTitle("Runner Tracker")
                .setContentText("Keep Running!")
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        notificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    private void initializeNotificationManager() {
        notificationManager = (NotificationManager)
                getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Runner Tracker";
            String description = "Keep Running!";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name,
                    importance);
            channel.setDescription(description);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
