package com.example.runnertracker.View;

import static android.app.Service.STOP_FOREGROUND_REMOVE;
import static com.example.runnertracker.Model.GPSService.ACTION_UPDATE_DATA;
import static com.example.runnertracker.Model.GPSService.EXTRA_DISTANCE;
import static com.example.runnertracker.Model.GPSService.EXTRA_TIME;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import com.example.runnertracker.Model.GPSService;
import com.example.runnertracker.R;

/*
    Used to call GPS service, provides user a means to view if they're movement is being tracked
    and then stop said tracking.

    BroadcastReciever used to receive one way communication from GPS service, gets GPS duration
     + distance.
 */
public class RunnerTracker extends AppCompatActivity {

    private MutableLiveData<Boolean> booleanLiveData;
    private String mDistance;
    private String mDuration;
    FrameLayout mFrameLayoutStart;
    FrameLayout mFrameLayoutStop;
    Intent mIntent = null;
    private boolean mTerminateService = false;
    private boolean mStopFrame = false;
    public static final String EXTRA_TERMINATE = "com.example.runnertracker.EXTRA_TERMINATE";
    public static final String PREF_FRAME = "PREF_FRAME";
    public static final String PREF_FRAME_STOP_LAYOUT = "PREF_FRAME_STOP_LAYOUT";

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ACTION_UPDATE_DATA)) {
                String distance = intent.getStringExtra(EXTRA_DISTANCE);
                String duration = intent.getStringExtra(EXTRA_TIME);

                mDistance = distance;
                mDuration = duration;

                toggleBroadcastReccieved();
            }
        }

    };

    /*
        Starts/Stops tracking location via floating action button
        Also checks if Broadcast receiver has received data, if yes then sends intent data to MainActivity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("comp3018", "ONCREATE CALLED");

        setContentView(R.layout.activity_runner_tracker);
        mFrameLayoutStart = findViewById(R.id.frame_layout_start);
        mFrameLayoutStop = findViewById(R.id.frame_layout_stop);
        buttonListener();

        InitializeBroadcastManager();
        hasBroadcastBeenRecieved();

        toggleStartStopVisibility();
    }

    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences previewSizePref = getSharedPreferences(PREF_FRAME, MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = previewSizePref.edit();
        prefEditor.putBoolean(PREF_FRAME_STOP_LAYOUT, isStopFrame());
        prefEditor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mReceiver == null) {
            InitializeBroadcastManager();
        }
        SharedPreferences previewSizePref = getSharedPreferences(PREF_FRAME, MODE_PRIVATE);
        if (previewSizePref.contains(PREF_FRAME_STOP_LAYOUT)) {
           toggleStartStopVisibility();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mIntent != null) {
            stopService(mIntent);
        }

        if (mReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiver);
        }
        mReceiver = null;
    }

    public void buttonListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            public void onClick(View view) {
                mIntent = new Intent(RunnerTracker.this, GPSService.class);
                switch (view.getId()) {
                    case R.id.floating_button_start:
                        mFrameLayoutStart.setVisibility(View.GONE);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(mIntent);
                        }
                        mFrameLayoutStop.setVisibility(View.VISIBLE);
                        setStopFrame(true);
                        break;
                    case R.id.floating_button_stop:
                        setTerminateService(true);
                        mFrameLayoutStop.setVisibility(View.GONE);
                        mIntent.putExtra(EXTRA_TERMINATE, isTerminateService());
                        mIntent.setAction("STOP");
                        startService(mIntent);
                        mFrameLayoutStart.setVisibility(View.VISIBLE);
                         setStopFrame(false);
                        break;
                }
            }
        };

        findViewById(R.id.floating_button_start).setOnClickListener(listener);
        findViewById(R.id.floating_button_stop).setOnClickListener(listener);
    }

    private void InitializeBroadcastManager() {
        final IntentFilter intentFilter = new IntentFilter(ACTION_UPDATE_DATA);
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, intentFilter);
    }

    private void hasBroadcastBeenRecieved() {
        booleanLiveData = new MutableLiveData<>();
        booleanLiveData.setValue(false); // initialises value to false to ensure empty data isn't sent to MainActivity.

        booleanLiveData.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean aBoolean) {
                if (aBoolean != null) {
                    if(aBoolean) {
                        Intent data = new Intent();
                        data.putExtra(EXTRA_DISTANCE, mDistance);
                        data.putExtra(EXTRA_TIME, mDuration);
                        setResult(RESULT_OK, data);
                        finish();
                    }
                }
            }
        });
    }

    private void toggleStartStopVisibility() {
        if(isStopFrame()) {
            mFrameLayoutStart.setVisibility(View.GONE);
            mFrameLayoutStop.setVisibility(View.VISIBLE);
        }
        else {
            mFrameLayoutStop.setVisibility(View.GONE);
            mFrameLayoutStart.setVisibility(View.VISIBLE);
        }
    }

    private void toggleBroadcastReccieved() {
        booleanLiveData.setValue(!booleanLiveData.getValue());
    }

    public boolean isStopFrame() {
        return mStopFrame;
    }

    public void setStopFrame(boolean mStopFrame) {
        this.mStopFrame = mStopFrame;
    }


    public boolean isTerminateService() {
        return mTerminateService;
    }

    public void setTerminateService(boolean mTerminateService) {
        this.mTerminateService = mTerminateService;
    }



}